The top-level test/ directory contains project-wide tests.
Each individual component or module should also include a unit test, 
which should be placed in the test directory for each component or module.