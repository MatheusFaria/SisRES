The static content of your web site (HTML pages, JSP pages, JavaScript files, CSS stylesheet files, and images) 
that will be accessible to application clients. This directory will be the document root of your web application, 
and any subdirectory structure found here will be reflected in the request URIs required to access those files