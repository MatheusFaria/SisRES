The special configuration files required for your application, including the web application deployment descriptor (web.xml),
tag library descriptors for custom tag libraries you have created, and other resource files you wish to include within your 
web application. Even though this directory appears to be a subdirectory of your document root, 
the Servlet Specification prohibits serving the contents of this directory (or any file it contains) directly to a client 
request. Therefore, this is a good place to store configuration information that is sensitive (such as database connection 
usernames and passwords), but is required for your application to operate successfully.