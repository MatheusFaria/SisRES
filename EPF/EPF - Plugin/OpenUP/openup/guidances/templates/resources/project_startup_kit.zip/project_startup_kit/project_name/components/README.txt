Components specific to more than one application in a project, organized by layers. 
Components used in only one application should be placed as part of that application.